<?php
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
//header("Content-Type: text/html; charset=utf8");
header("Content-Type: application/json"); 
require_once 'PHPExcel/Classes/PHPExcel.php';
require_once 'PHPExcel/Classes/PHPExcel/Worksheet.php';
require_once 'PHPExcel/Classes/PHPExcel/IOFactory.php';	
require_once 'transformer.lib';	
	

if (file_exists('list_of_alcohol/vvp.xls')) {
	$tr = new Transformer('list_of_alcohol/vvp.xls', 12);
}else{
	print_r('Wrong path or file not exist.');
}
if ( $tr->defindFile() ) { print_r('File is good'); }

	
?>